<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Goede Morgen</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>



<main>

    <header>
        <h1>Mad libs</h1>
    </header>

    <nav>
        <ul>
            <li><h2>Maak een verhaal!</h2></li>
        </ul>
    </nav>

    <div id="question-box">
        <h3>Beantwoord de vragen.</h3>

        <p>Welk persoon mag je niet                 :<input value="<?php echo $persoon;?>"> </p>
        <p>Welk dier mag je niet                    :<input value="<?php echo $getal;?>"></p>
        <p>Wat is je lievelings getal               :<input value="<?php echo $dier;?>"></p>
        <p>Welk persoon mag je wel                  :<input value="<?php echo $fPersoon;?>"></p>
        <p>Wat was vroeger je lievelings speelgoed  :<input value="<?php echo $speelgoed;?>"></p>
        <p><input></p>
        <button onclick="knop()"></button>

        <div id="php">
            <?php

            function knop {
                echo ""
        }

            $persoon = htmlspecialchars($_POST['name']);htmlspecialchars($_POST['persoon']);

            echo "<p>De boosaardige " . $persoon . " heeft een leger opgebouwd dat bestaat uit " . $getal . $dier . "! " . $fPersoon . " probeerd ze te stoppen met " . $speelgoed . ", maar het lukt niet. Oke, poging 2 dan maar! </p>";

            echo "<body style='background-image: url();'>";
            echo "<body style='background-image: url();'>";

            ?>
        </div>

    </div>



</main>



</body>
</html>
