<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Goede Morgen</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>



<main>

    <header>
        <h1>Mad libs</h1>
    </header>

    <nav>
        <ul>
            <li><h2>Je verhaal!</h2></li>
        </ul>
    </nav>

    <div class="box">
        <p>De boosaardige <?php echo $_GET["persoon"]; ?> heeft een leger opgebouwd dat bestaat uit <?php echo $_GET["getal"]; ?> <?php echo $_GET["dier"]; ?>! De enige echte <?php echo $_GET["fpersoon"]; ?> probeerd ze te stoppen met <?php echo $_GET["speelgoed"]; ?>, maar het lukt niet. Oke, poging 2 dan maar! Met een <?php echo $_GET["wapen"]; ?> worden ze allemaal weg gejaagt! Al <?php echo $_GET["traan"]; ?> rennen ze allemaal boos weg.</p>
    </div>

    <footer>Deze website is gemaakt door Mel.</footer>

</main>



</body>
</html>
